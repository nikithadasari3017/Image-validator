import json
import boto3
from PIL import Image
import os

s3 = boto3.client('s3')

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    file_path = '/tmp/' + key
    s3.download_file(bucket, key, file_path)

    file_size = os.path.getsize(file_path)

    if file_size > 5000000:
        return {
            'statusCode': 400,
            'body': 'File too large'
        }

    try:
        img = Image.open(file_path)
        width, height = img.size

        if width < 200 or height < 200:
            return {
                'statusCode': 400,
                'body': 'Image too small'
            }

        return {
            'statusCode': 200,
            'body': 'Valid image'
        }

    except:
        return {
            'statusCode': 400,
            'body': 'Invalid image format'
        }